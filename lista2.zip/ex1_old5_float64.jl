# list 1 ex 5
# author: Michał Osman

x = [2.718281828, -3.141592654, 1.414213562, 0.5772156649, 0.3010299957]
y = [1486.2497, 878366.9879, -22.37492, 4773714.647, 0.000185049]
n = 5

function a()
    S = 0.0
    for i = 1:n
        S = S + x[i] * y[i]
    end
    return S
end

function b()
    S = 0.0
    i = n
    while i > 0
        S = S + x[i] * y[i]
        i = i - 1
    end
    return S
end

function c()
    A = Array{Float64, 1}(n)
    for i = 1:n
        A[i] = x[i] * y[i]
    end
    A = sort(A)

    P = 0.0
    N = 0.0
    negativeEnd = 0
    i = 1
    while A[i] < 0 && i <= n
        negativeEnd = i
        i = i + 1
    end

    i = n
    while i > negativeEnd
        P = P + A[i]
        i = i - 1
    end


    for i = 1: negativeEnd
        N = N + A[i]
    end

    return P + N
end


function d()
    A = Array{Float64, 1}(n)
    for i = 1:n
        A[i] = x[i] * y[i]
    end
    A = sort(A)

    P = 0.0
    N = 0.0
    negativeEnd = 0
    i = 1
    while A[i] < 0 && i <= n
        negativeEnd = i
        i = i + 1
    end

    for i = negativeEnd + 1:n
        P = P + A[i]
    end

    i = negativeEnd
    while i > 0
        N = N + A[i]
        i = i - 1
    end

    return N + P
end


print(a())
print(b())
print(c())
print(d())
