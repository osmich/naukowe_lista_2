
f(x,c) = Float64(x^2 + c)

loop = function(x,c)
    x0 = Float64(x)
    for i = 1:40
        x0 = f(x0, c)
        # print(i,":\t", x0, "\n")
        print(x0, "\n")
    end
end

loopValues = function(x,c)
    x0 = Float64(x)
    arr = Array{Float64, 1}(40)
    for i = 1:40
        x0 = f(x0, c)
        arr[i] = x0
    end
    return arr
end

# f(0.75, -1)
loop(1, -2)
loop(2, -2)
loop(1.99999999999999, -2)
loop(1, -1)
loop(-1, -1)
loop(0.75, -1)
loop(0.25, -1)

C = -2
C2 = -1
f2(x) = f(x,C)
f3(x) = f(x, C2)
using Plots

plotly()

plot([loopValues(1, -2),
    loopValues(2, -2),
    loopValues(1.99999999999999, -2)],
    ls=[:dash :dashdot :dashdotdot],
    lab=["x0 = 2, c = -2" "x0 = 1.99999999999999, c = -2"])
plot([
    loopValues(0.75, -1),
    loopValues(0.25, -1)],
    ls=[:dash :dashdotdot],
    lab=["x0 = 0.75, c = -1" "x0 = 0.25, c = -1"])

plot([
    loopValues(1, -1),
    loopValues(-1, -1)],
    # ls=[:dash :dashdot],    
    lab=["x0 = 1, c = -1" "x0 = -1, c = -1"])

loopValues(1,-2)
