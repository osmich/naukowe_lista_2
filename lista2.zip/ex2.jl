using Plots

plotly()
e = 2.718281828459
f(x) = e^(x)*log(1+e^(-x))
plot(f,linewidth=2,title="e^(x)log(1+e^(-x)",
    xlabel="x",
    ylabel="y", lab="e^(x)log(1+e^(-x))", size=(600,200))
