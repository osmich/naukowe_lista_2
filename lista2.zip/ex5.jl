

function f64(pn::Float64, r::Int)
    return Float64(pn+(r*pn*(1 - pn)))
end

function f32(pn::Float32, r::Int)
    return Float32(pn+(r*pn*(1 - pn)))
end


r = 3
p0 = 0.01
pn1 = Float64(p0)
pn2 = Float32(p0)

print("\n\tFloat 64\t\t\t\t\tFloat32\n")
for i = 1:40
    pn1 = f64(pn1, r)
    pn2 = f32(pn2, r)
    print(i, "\t: ", pn1, "\t\t\t", pn2,'\n')
end

function cut64()
    r = 3
    p0 = 0.01
    pn1 = Float64(p0)
    pn2 = Float64(p0)

    print("\n\nFloat64 cut at 10\n")
    for i = 1:9
        pn1 = f64(pn1, r)
        pn2 = f64(pn2, r)
        print(i, "\t", pn1, "\t\t\t", pn2,'\n')
    end
    pn1 = f64(pn1, r)
    pn2 = f64(pn2, r)
    pn2 = floor(pn2, 3)
    print(10, "\t", pn1, "\t\t\t", pn2, '\n')
    for i = 11:40
        pn1 = f64(pn1, r)
        pn2 = f64(pn2, r)
        print(i, "\t", pn1, "\t\t\t", pn2, '\n')
    end
end

function cut32()
    r = 3
    p0 = 0.01
    pn1 = Float32(p0)
    pn2 = Float32(p0)

    print("\n\nFloat32 cut at 10\n")
    for i = 1:9
        pn1 = f32(pn1, r)
        pn2 = f32(pn2, r)
        print(i, "\t", pn1, "\t\t\t", pn2,'\n')
    end
    pn1 = f32(pn1, r)
    pn2 = f32(pn2, r)
    pn2 = floor(pn2, 3)
    print(10, "\t", pn1, "\t\t\t", pn2, '\n')
    for i = 11:40
        pn1 = f32(pn1, r)
        pn2 = f32(pn2, r)
        print(i, "\t", pn1, "\t\t\t", pn2, '\n')
    end
end

cut64()
cut32()
